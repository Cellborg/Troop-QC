from .models import QCMetricsRequest
from .modules.qcmetrics import calculate_qc_metrics
from fastapi import APIRouter

router = APIRouter()


@router.get("/items/{item_id}")
async def read_item(item_id: int, q: str = None):
    return {"item_id": item_id, "q": q}


@router.post("/qc_metrics")
async def qc_metrics(request: QCMetricsRequest):

    await calculate_qc_metrics(request)
    
    return {"success": True, "message": "QC Pre-Plot Completed Successfully"}
